<?php
	// $conn = mysqli_connect('localhost', 'marieade_school', 'OPTIMUSprime#1');
	// if($conn){
	// 	mysqli_select_db($conn, 'marieade_adelaide') or die("Database acesss error: ".mysqli_error($conn));
	// }else{
	// 	$conn = mysqli_connect('localhost', 'id235756_ok', 'aquavert');
	// 	mysqli_select_db($conn, 'id235756_comwork') or die("Database acesss error: ".mysqli_error($conn));
	// }

	$conn = new mysqli('localhost', 'edoricac_aqvert', 'aquavert', 'edoricac_aqvert');
?>